from flask import Flask, render_template, redirect, request, url_for, session ,jsonify
import sqlite3 as sql

app = Flask(__name__)


@app.route('/')
def index():
    rows = []
    try:
        con = sql.connect("database.db")
        con.row_factory = sql.Row
        cur = con.cursor()
        cur.execute("select * from POLLS")
        rows = cur.fetchall()
    except:
        con.rollback()
        msg = "error in insert operation"
    return render_template('index.html', rows=rows)


def isAdmin(emnail):
    admin = ''
    isAdmin = False
    con = sql.connect("database.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM USERS where email=? ", (emnail,))
    for row in cur.fetchall():
        admin = row[4]

    if admin == 'yes':
        isAdmin = True
        return isAdmin
    else:
        isAdmin = False
        return isAdmin
    return isAdmin


@app.route('/dashboard')
def dashboard():
    if 'log' in session:
        return redirect(url_for('dashboard'))
    else:
        return render_template('login.html')
    return redirect(url_for('dashboard'))


@app.route('/login', methods=['POST', 'GET'])
def login():
    error = ''
    rows = ''
    if request.method == 'POST':
        con = sql.connect("database.db")
        cur = con.cursor()
        cur.execute("SELECT COUNT(*) FROM USERS where email=? and password=? ", (request.form['username'],
                                                                                 request.form['password']))
        rows = int(cur.fetchone()[0])
        if rows == 1:
            isTrue = isAdmin(request.form['username'])
            if isTrue is True:
                session['admin'] = request.form['username']
                return redirect(url_for('list'))
            else:
                session['log'] = request.form['username']
                return redirect(url_for('index'))
        else:
            error = 'User name and password is wrong'
            render_template('login.html', error=error)

    return render_template('login.html', error=error)


@app.route('/success')
def success():
    return 'logged in successfully'


@app.route('/registration')
def newreg():
    return render_template('reg.html')


@app.route('/registrationview', methods=['POST', 'GET'])
def addrec():
    msg = ''
    if request.method == 'POST':
        try:
            name = request.form['name']
            email = request.form['email']
            password = request.form['password']
            admin = request.form['admin']
            with sql.connect("database.db") as con:
                cur = con.cursor()
                cur.execute("INSERT INTO USERS (email, name, password,isadmin) VALUES(?, ?, ?,?)",
                            (email, name, password, admin))

                con.commit()
                msg = "Record successfully added"
        except:
            con.rollback()
            msg = "error in insert operation"

        finally:
            return render_template("result.html", msg=msg)
            con.close()
    return render_template("result.html", msg=msg)


@app.route('/admin')
def list():
    rows = []
    pools = []
    if session.get('admin') is not None:
        con = sql.connect("database.db")
        con.row_factory = sql.Row
        cur = con.cursor()
        cur1 = con.cursor()
        cur.execute("select * from USERS")
        rows = cur.fetchall()
        cur1.execute("select * from POLLS")
        pools = cur1.fetchall()
    else:
        return render_template('permission.html', per='You have no permission for access admin page')
    return render_template("list.html", rows=rows, pools=pools)


@app.route("/logout")
def logout():
    session.pop('log', None)
    session.pop('admin', None)
    return render_template("logout.html")


@app.route('/api/delete/<int:_id>', methods=['DELETE'])
def delete(_id):
    postID = int(_id)
    msg = ''
    if request.method == 'DELETE':
        try:
            with sql.connect("database.db") as con:
                cur = con.cursor()
                cur.execute("Delete from  POLLS where poll_id=?", (_id,))
                con.commit()
                msg = "Record delete "
        except:
            con.rollback()
            msg = "error in delete operation"

        finally:
            return "Deleted: {} \n".format(msg)
            con.close()
    return "Deleted: {} \n".format(msg)


@app.route('/api/delete/user/<string:_id>', methods=['DELETE'])
def delete_user(_id):
    msg = ''
    if request.method == 'DELETE':
        try:
            with sql.connect("database.db") as con:
                cur = con.cursor()
                cur.execute("Delete from  USERS where email=?", (_id,))
                con.commit()
                msg = "Record delete "
        except:
            con.rollback()
            msg = "error in delete operation"

        finally:
            return "Deleted: {} \n".format(msg)
            con.close()
    return "Deleted: {} \n".format(msg)


@app.route('/pollCreate', methods=['POST', 'GET'])
def pollCreate():
    rows = []
    msg = ''
    if session.get('admin') is not None:
        with sql.connect("database.db") as con:
            con.row_factory = sql.Row
            cur = con.cursor()
            cur.execute("select * from POLLS")
            rows = cur.fetchall()
            if request.method == 'POST':
                try:
                    ques = request.form['ques']
                    op1 = request.form['option1']
                    op2 = request.form['option2']
                    op3 = request.form['option3']
                    op4 = request.form['option4']
                    cur = con.cursor()
                    cur.execute("INSERT INTO POLLS (question, option1, option2,option3,option4) VALUES(?, ?, ?,?,?)",
                                (ques, op1, op2, op3, op4))

                    con.commit()
                    msg = "Polls Create sucessfully"
                except:
                    con.rollback()
                    msg = "error in insert operation"

                finally:
                    return render_template("pollsCreate.html", msg=msg , rows=rows)
                con.close()
    else:
        return render_template('permission.html', per='You have no permission to create vote this is only for admin')
    return render_template("pollsCreate.html", msg=msg , rows=rows)


@app.route('/api/vote/<int:_id>', methods=['PUT'])
def user_vote(_id):
    msg = ''
    if request.method == 'PUT':
        try:
            with sql.connect("database.db") as con:
                cur = con.cursor()
                cur.execute("UPDATE POLLS SET count = ? WHERE poll_id = ?", (int(request.data.get('count', '')), int(_id)))
                con.commit()
                msg = "You have successfully vote "
        except:
            con.rollback()
            msg = "error in vote operation"
            print(_id)

        finally:
            return "Message: {} \n".format(msg)
            con.close()
    return ": Message{} \n".format(msg)


if __name__ == '__main__':
    app.secret_key = 'hbfdsbjkjkfdbgjkdfkjgd'
    app.debug = True
    app.run(host='localhost', port=3030)





