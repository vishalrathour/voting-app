import sqlite3

conn = sqlite3.connect('database.db')
print
"Opened database successfully"

query = "create TABLE IF NOT EXISTS USERS (user_id integer PRIMARY KEY, email text , voteoptions text , name text , password text, isadmin text )"
query1 = "create TABLE IF NOT EXISTS POLLS (poll_id integer PRIMARY KEY, question  text NOT NULL, option1  text NOT NULL , option2  text NOT NULL, option3  text NOT NULL, option4 text NOT NULL, count  integer NOT NULL default 0)"

conn.execute(query)
conn.execute(query1)
print
"Table created successfully"
conn.close()


